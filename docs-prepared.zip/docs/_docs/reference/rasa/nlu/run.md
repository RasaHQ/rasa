---
sidebar_label: rasa.nlu.run
title: rasa.nlu.run
---
#### run\_cmdline

```python
run_cmdline(model_path: Text) -> None
```

Loops over CLI input, passing each message to a loaded NLU model.

