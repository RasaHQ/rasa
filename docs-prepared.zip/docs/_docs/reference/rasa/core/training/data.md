---
sidebar_label: rasa.core.training.data
title: rasa.core.training.data
---
## DialogueTrainingData Objects

```python
class DialogueTrainingData()
```

#### is\_empty

```python
 | is_empty() -> bool
```

Check if the training matrix does contain training samples.

