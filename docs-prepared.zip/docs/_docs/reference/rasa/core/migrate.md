---
sidebar_label: rasa.core.migrate
title: rasa.core.migrate
---
#### migrate\_domain\_format

```python
migrate_domain_format(domain_file: Union[Text, Path], out_file: Union[Text, Path]) -> None
```

Converts 2.0 domain to 3.0 format.

