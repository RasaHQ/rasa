---
sidebar_label: rasa.core.channels.rasa_chat
title: rasa.core.channels.rasa_chat
---
## RasaChatInput Objects

```python
class RasaChatInput(RestInput)
```

Chat input channel for Rasa X

#### \_\_init\_\_

```python
 | __init__(url: Optional[Text]) -> None
```

Initialise the channel with attributes.

