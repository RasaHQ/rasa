---
sidebar_label: rasa.core.config
title: rasa.core.config
---
#### load

```python
load(config_file: Union[Text, Dict]) -> List["Policy"]
```

Load policy data stored in the specified file.

