
import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/docs/rasa/apis/http/',
    component: ComponentCreator('/docs/rasa/apis/http/','e25'),
    exact: true
  },
  {
    path: '/docs/rasa/search/',
    component: ComponentCreator('/docs/rasa/search/','e05'),
    exact: true
  },
  {
    path: '/docs/rasa/2.x/',
    component: ComponentCreator('/docs/rasa/2.x/','6a3'),
    routes: [
      {
        path: '/docs/rasa/2.x/',
        component: ComponentCreator('/docs/rasa/2.x/','b6a'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/actions/',
        component: ComponentCreator('/docs/rasa/2.x/actions/','c89'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/arch-overview/',
        component: ComponentCreator('/docs/rasa/2.x/arch-overview/','32d'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/architecture/',
        component: ComponentCreator('/docs/rasa/2.x/architecture/','5f0'),
        exact: true
      },
      {
        path: '/docs/rasa/2.x/business-logic/',
        component: ComponentCreator('/docs/rasa/2.x/business-logic/','c79'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/changelog/',
        component: ComponentCreator('/docs/rasa/2.x/changelog/','3ee'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/chitchat-faqs/',
        component: ComponentCreator('/docs/rasa/2.x/chitchat-faqs/','c13'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/command-line-interface/',
        component: ComponentCreator('/docs/rasa/2.x/command-line-interface/','6cf'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/components/',
        component: ComponentCreator('/docs/rasa/2.x/components/','a1b'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/connectors/cisco-webex-teams/',
        component: ComponentCreator('/docs/rasa/2.x/connectors/cisco-webex-teams/','7c7'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/connectors/custom-connectors/',
        component: ComponentCreator('/docs/rasa/2.x/connectors/custom-connectors/','23c'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/connectors/facebook-messenger/',
        component: ComponentCreator('/docs/rasa/2.x/connectors/facebook-messenger/','2bf'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/connectors/hangouts/',
        component: ComponentCreator('/docs/rasa/2.x/connectors/hangouts/','8d5'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/connectors/mattermost/',
        component: ComponentCreator('/docs/rasa/2.x/connectors/mattermost/','a59'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/connectors/microsoft-bot-framework/',
        component: ComponentCreator('/docs/rasa/2.x/connectors/microsoft-bot-framework/','975'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/connectors/rocketchat/',
        component: ComponentCreator('/docs/rasa/2.x/connectors/rocketchat/','7de'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/connectors/slack/',
        component: ComponentCreator('/docs/rasa/2.x/connectors/slack/','4be'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/connectors/telegram/',
        component: ComponentCreator('/docs/rasa/2.x/connectors/telegram/','25b'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/connectors/twilio-voice/',
        component: ComponentCreator('/docs/rasa/2.x/connectors/twilio-voice/','c2c'),
        exact: true
      },
      {
        path: '/docs/rasa/2.x/connectors/twilio/',
        component: ComponentCreator('/docs/rasa/2.x/connectors/twilio/','383'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/connectors/your-own-website/',
        component: ComponentCreator('/docs/rasa/2.x/connectors/your-own-website/','c5f'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/contextual-conversations/',
        component: ComponentCreator('/docs/rasa/2.x/contextual-conversations/','da9'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/conversation-driven-development/',
        component: ComponentCreator('/docs/rasa/2.x/conversation-driven-development/','fd8'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/custom-actions/',
        component: ComponentCreator('/docs/rasa/2.x/custom-actions/','762'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/default-actions/',
        component: ComponentCreator('/docs/rasa/2.x/default-actions/','063'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/docker/building-in-docker/',
        component: ComponentCreator('/docs/rasa/2.x/docker/building-in-docker/','ec7'),
        exact: true
      },
      {
        path: '/docs/rasa/2.x/docker/deploying-in-docker-compose/',
        component: ComponentCreator('/docs/rasa/2.x/docker/deploying-in-docker-compose/','18a'),
        exact: true
      },
      {
        path: '/docs/rasa/2.x/domain/',
        component: ComponentCreator('/docs/rasa/2.x/domain/','a74'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/event-brokers/',
        component: ComponentCreator('/docs/rasa/2.x/event-brokers/','0ce'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/fallback-handoff/',
        component: ComponentCreator('/docs/rasa/2.x/fallback-handoff/','2eb'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/forms/',
        component: ComponentCreator('/docs/rasa/2.x/forms/','2a8'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/generating-nlu-data/',
        component: ComponentCreator('/docs/rasa/2.x/generating-nlu-data/','6db'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/glossary/',
        component: ComponentCreator('/docs/rasa/2.x/glossary/','713'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/how-to-deploy/',
        component: ComponentCreator('/docs/rasa/2.x/how-to-deploy/','26b'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/http-api/',
        component: ComponentCreator('/docs/rasa/2.x/http-api/','94f'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/installation/',
        component: ComponentCreator('/docs/rasa/2.x/installation/','00c'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/jupyter-notebooks/',
        component: ComponentCreator('/docs/rasa/2.x/jupyter-notebooks/','361'),
        exact: true
      },
      {
        path: '/docs/rasa/2.x/language-support/',
        component: ComponentCreator('/docs/rasa/2.x/language-support/','9d2'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/lock-stores/',
        component: ComponentCreator('/docs/rasa/2.x/lock-stores/','401'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/messaging-and-voice-channels/',
        component: ComponentCreator('/docs/rasa/2.x/messaging-and-voice-channels/','114'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/migrate-from/',
        component: ComponentCreator('/docs/rasa/2.x/migrate-from/','b2a'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/migrate-from/facebook-wit-ai-to-rasa/',
        component: ComponentCreator('/docs/rasa/2.x/migrate-from/facebook-wit-ai-to-rasa/','c30'),
        exact: true
      },
      {
        path: '/docs/rasa/2.x/migrate-from/google-dialogflow-to-rasa/',
        component: ComponentCreator('/docs/rasa/2.x/migrate-from/google-dialogflow-to-rasa/','b8d'),
        exact: true
      },
      {
        path: '/docs/rasa/2.x/migrate-from/ibm-watson-to-rasa/',
        component: ComponentCreator('/docs/rasa/2.x/migrate-from/ibm-watson-to-rasa/','831'),
        exact: true
      },
      {
        path: '/docs/rasa/2.x/migrate-from/microsoft-luis-to-rasa/',
        component: ComponentCreator('/docs/rasa/2.x/migrate-from/microsoft-luis-to-rasa/','c19'),
        exact: true
      },
      {
        path: '/docs/rasa/2.x/migration-guide/',
        component: ComponentCreator('/docs/rasa/2.x/migration-guide/','009'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/model-configuration/',
        component: ComponentCreator('/docs/rasa/2.x/model-configuration/','b01'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/model-storage/',
        component: ComponentCreator('/docs/rasa/2.x/model-storage/','133'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/nlg/',
        component: ComponentCreator('/docs/rasa/2.x/nlg/','28b'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/nlu-only-server/',
        component: ComponentCreator('/docs/rasa/2.x/nlu-only-server/','83f'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/nlu-only/',
        component: ComponentCreator('/docs/rasa/2.x/nlu-only/','daf'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/nlu-training-data/',
        component: ComponentCreator('/docs/rasa/2.x/nlu-training-data/','ee3'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/playground/',
        component: ComponentCreator('/docs/rasa/2.x/playground/','3fe'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/policies/',
        component: ComponentCreator('/docs/rasa/2.x/policies/','499'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/reaching-out-to-user/',
        component: ComponentCreator('/docs/rasa/2.x/reaching-out-to-user/','a22'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/responses/',
        component: ComponentCreator('/docs/rasa/2.x/responses/','04e'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/rules/',
        component: ComponentCreator('/docs/rasa/2.x/rules/','580'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/setting-up-ci-cd/',
        component: ComponentCreator('/docs/rasa/2.x/setting-up-ci-cd/','295'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/stories/',
        component: ComponentCreator('/docs/rasa/2.x/stories/','be8'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/telemetry/',
        component: ComponentCreator('/docs/rasa/2.x/telemetry/','e39'),
        exact: true
      },
      {
        path: '/docs/rasa/2.x/telemetry/reference/',
        component: ComponentCreator('/docs/rasa/2.x/telemetry/reference/','c1d'),
        exact: true
      },
      {
        path: '/docs/rasa/2.x/testing-your-assistant/',
        component: ComponentCreator('/docs/rasa/2.x/testing-your-assistant/','b16'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/tracker-stores/',
        component: ComponentCreator('/docs/rasa/2.x/tracker-stores/','4f4'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/training-data-format/',
        component: ComponentCreator('/docs/rasa/2.x/training-data-format/','cb5'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/training-data-importers/',
        component: ComponentCreator('/docs/rasa/2.x/training-data-importers/','ed9'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/tuning-your-model/',
        component: ComponentCreator('/docs/rasa/2.x/tuning-your-model/','e7e'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/unexpected-input/',
        component: ComponentCreator('/docs/rasa/2.x/unexpected-input/','22c'),
        exact: true,
        'sidebar': "version-2.x/default"
      },
      {
        path: '/docs/rasa/2.x/writing-stories/',
        component: ComponentCreator('/docs/rasa/2.x/writing-stories/','b67'),
        exact: true,
        'sidebar': "version-2.x/default"
      }
    ]
  },
  {
    path: '/docs/rasa/',
    component: ComponentCreator('/docs/rasa/','885'),
    routes: [
      {
        path: '/docs/rasa/',
        component: ComponentCreator('/docs/rasa/','922'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/actions/',
        component: ComponentCreator('/docs/rasa/actions/','fe5'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/actively-maintained-versions/',
        component: ComponentCreator('/docs/rasa/actively-maintained-versions/','295'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/arch-overview/',
        component: ComponentCreator('/docs/rasa/arch-overview/','242'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/architecture/',
        component: ComponentCreator('/docs/rasa/architecture/','8b1'),
        exact: true
      },
      {
        path: '/docs/rasa/business-logic/',
        component: ComponentCreator('/docs/rasa/business-logic/','3e5'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/changelog/',
        component: ComponentCreator('/docs/rasa/changelog/','64a'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/chitchat-faqs/',
        component: ComponentCreator('/docs/rasa/chitchat-faqs/','d30'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/command-line-interface/',
        component: ComponentCreator('/docs/rasa/command-line-interface/','fc1'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/components/',
        component: ComponentCreator('/docs/rasa/components/','cfa'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/connectors/cisco-webex-teams/',
        component: ComponentCreator('/docs/rasa/connectors/cisco-webex-teams/','4ce'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/connectors/custom-connectors/',
        component: ComponentCreator('/docs/rasa/connectors/custom-connectors/','64f'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/connectors/facebook-messenger/',
        component: ComponentCreator('/docs/rasa/connectors/facebook-messenger/','c7f'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/connectors/hangouts/',
        component: ComponentCreator('/docs/rasa/connectors/hangouts/','430'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/connectors/mattermost/',
        component: ComponentCreator('/docs/rasa/connectors/mattermost/','05f'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/connectors/microsoft-bot-framework/',
        component: ComponentCreator('/docs/rasa/connectors/microsoft-bot-framework/','b0b'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/connectors/rocketchat/',
        component: ComponentCreator('/docs/rasa/connectors/rocketchat/','b21'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/connectors/slack/',
        component: ComponentCreator('/docs/rasa/connectors/slack/','d15'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/connectors/telegram/',
        component: ComponentCreator('/docs/rasa/connectors/telegram/','b37'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/connectors/twilio-voice/',
        component: ComponentCreator('/docs/rasa/connectors/twilio-voice/','85a'),
        exact: true
      },
      {
        path: '/docs/rasa/connectors/twilio/',
        component: ComponentCreator('/docs/rasa/connectors/twilio/','847'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/connectors/your-own-website/',
        component: ComponentCreator('/docs/rasa/connectors/your-own-website/','641'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/contextual-conversations/',
        component: ComponentCreator('/docs/rasa/contextual-conversations/','e94'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/conversation-driven-development/',
        component: ComponentCreator('/docs/rasa/conversation-driven-development/','e95'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/custom-actions/',
        component: ComponentCreator('/docs/rasa/custom-actions/','3d1'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/custom-graph-components/',
        component: ComponentCreator('/docs/rasa/custom-graph-components/','e85'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/default-actions/',
        component: ComponentCreator('/docs/rasa/default-actions/','b27'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/docker/building-in-docker/',
        component: ComponentCreator('/docs/rasa/docker/building-in-docker/','a06'),
        exact: true
      },
      {
        path: '/docs/rasa/docker/deploying-in-docker-compose/',
        component: ComponentCreator('/docs/rasa/docker/deploying-in-docker-compose/','b73'),
        exact: true
      },
      {
        path: '/docs/rasa/domain/',
        component: ComponentCreator('/docs/rasa/domain/','dd2'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/event-brokers/',
        component: ComponentCreator('/docs/rasa/event-brokers/','42e'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/fallback-handoff/',
        component: ComponentCreator('/docs/rasa/fallback-handoff/','e16'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/forms/',
        component: ComponentCreator('/docs/rasa/forms/','d2c'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/generating-nlu-data/',
        component: ComponentCreator('/docs/rasa/generating-nlu-data/','1c3'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/glossary/',
        component: ComponentCreator('/docs/rasa/glossary/','fcd'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/how-to-deploy/',
        component: ComponentCreator('/docs/rasa/how-to-deploy/','9a2'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/http-api/',
        component: ComponentCreator('/docs/rasa/http-api/','cbd'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/installation/',
        component: ComponentCreator('/docs/rasa/installation/','e65'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/jupyter-notebooks/',
        component: ComponentCreator('/docs/rasa/jupyter-notebooks/','977'),
        exact: true
      },
      {
        path: '/docs/rasa/language-support/',
        component: ComponentCreator('/docs/rasa/language-support/','859'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/lock-stores/',
        component: ComponentCreator('/docs/rasa/lock-stores/','097'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/markers/',
        component: ComponentCreator('/docs/rasa/markers/','acd'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/messaging-and-voice-channels/',
        component: ComponentCreator('/docs/rasa/messaging-and-voice-channels/','f84'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/migrate-from/',
        component: ComponentCreator('/docs/rasa/migrate-from/','c7d'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/migrate-from/facebook-wit-ai-to-rasa/',
        component: ComponentCreator('/docs/rasa/migrate-from/facebook-wit-ai-to-rasa/','18b'),
        exact: true
      },
      {
        path: '/docs/rasa/migrate-from/google-dialogflow-to-rasa/',
        component: ComponentCreator('/docs/rasa/migrate-from/google-dialogflow-to-rasa/','ad0'),
        exact: true
      },
      {
        path: '/docs/rasa/migrate-from/ibm-watson-to-rasa/',
        component: ComponentCreator('/docs/rasa/migrate-from/ibm-watson-to-rasa/','7f1'),
        exact: true
      },
      {
        path: '/docs/rasa/migrate-from/microsoft-luis-to-rasa/',
        component: ComponentCreator('/docs/rasa/migrate-from/microsoft-luis-to-rasa/','a9b'),
        exact: true
      },
      {
        path: '/docs/rasa/migration-guide/',
        component: ComponentCreator('/docs/rasa/migration-guide/','384'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/model-configuration/',
        component: ComponentCreator('/docs/rasa/model-configuration/','c66'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/model-storage/',
        component: ComponentCreator('/docs/rasa/model-storage/','122'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/nlg/',
        component: ComponentCreator('/docs/rasa/nlg/','aae'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/nlu-only-server/',
        component: ComponentCreator('/docs/rasa/nlu-only-server/','20c'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/nlu-only/',
        component: ComponentCreator('/docs/rasa/nlu-only/','e63'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/nlu-training-data/',
        component: ComponentCreator('/docs/rasa/nlu-training-data/','ae6'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/playground/',
        component: ComponentCreator('/docs/rasa/playground/','3cb'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/policies/',
        component: ComponentCreator('/docs/rasa/policies/','e28'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/reaching-out-to-user/',
        component: ComponentCreator('/docs/rasa/reaching-out-to-user/','e7a'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/responses/',
        component: ComponentCreator('/docs/rasa/responses/','d90'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/rules/',
        component: ComponentCreator('/docs/rasa/rules/','e4d'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/setting-up-ci-cd/',
        component: ComponentCreator('/docs/rasa/setting-up-ci-cd/','4b3'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/slot-validation-actions/',
        component: ComponentCreator('/docs/rasa/slot-validation-actions/','8c2'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/stories/',
        component: ComponentCreator('/docs/rasa/stories/','fb6'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/telemetry/',
        component: ComponentCreator('/docs/rasa/telemetry/','3a2'),
        exact: true
      },
      {
        path: '/docs/rasa/telemetry/reference/',
        component: ComponentCreator('/docs/rasa/telemetry/reference/','501'),
        exact: true
      },
      {
        path: '/docs/rasa/testing-your-assistant/',
        component: ComponentCreator('/docs/rasa/testing-your-assistant/','fce'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/tracker-stores/',
        component: ComponentCreator('/docs/rasa/tracker-stores/','240'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/training-data-format/',
        component: ComponentCreator('/docs/rasa/training-data-format/','a3b'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/training-data-importers/',
        component: ComponentCreator('/docs/rasa/training-data-importers/','171'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/tuning-your-model/',
        component: ComponentCreator('/docs/rasa/tuning-your-model/','b37'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/unexpected-input/',
        component: ComponentCreator('/docs/rasa/unexpected-input/','2fc'),
        exact: true,
        'sidebar': "version-3.x/default"
      },
      {
        path: '/docs/rasa/writing-stories/',
        component: ComponentCreator('/docs/rasa/writing-stories/','cce'),
        exact: true,
        'sidebar': "version-3.x/default"
      }
    ]
  },
  {
    path: '*',
    component: ComponentCreator('*')
  }
];
