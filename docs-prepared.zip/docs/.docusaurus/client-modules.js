export default [
  require("/Users/lunelson/Git/rasahq/docusaurus-tabula/node_modules/docusaurus-theme-redoc/dist/custom.css"),
  require("/Users/lunelson/Git/rasahq/docusaurus-tabula/node_modules/infima/dist/css/default/default.css"),
  require("/Users/lunelson/Git/rasahq/docusaurus-tabula/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/Users/lunelson/Git/rasahq/docusaurus-tabula/node_modules/@docusaurus/theme-classic/lib/admonitions.css"),
  require("/Users/lunelson/Git/rasahq/docusaurus-tabula/packages/docusaurus-tabula/themes/tabula/styles/tabula.scss"),
];
